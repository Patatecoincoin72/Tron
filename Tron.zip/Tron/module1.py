"""
essai boost
"""
import pygame
from random import *
import csv
import tst
import time

#tableau de score

tab=tst.convert('data/scores.csv')

#constantes de la fenêtre d'affichage
LARGEUR=512                                                                      #hauteur de la fenêtre
HAUTEUR=540                                                                      #largeur de la fenêtre

BLANC=(255,255,255)
ROUGE=(255,0,0)                                                                  #définition couleurs
VERT=(0,255,0)
BLEU=(0,0,150)
BLEUF=(0,0,139)
ROSE=(255,67,117)
JAUNE=(249,225,69)
NOIR=(0,0,0)

#Utilisation de la bibliothèque pygame
pygame.init()
fenetre=pygame.display.set_mode((LARGEUR, HAUTEUR))
pygame.display.set_caption("PataTron")                                           #titre de la fenêtre
font=pygame.font.Font('freesansbold.ttf',20)                                     #choix de la police de caractères
frequence=pygame.time.Clock()                                                    #mode animation dans pygame

#moto rose
moto1X=(LARGEUR//3)*2
moto1Y=HAUTEUR//2
direction1='gauche'
boost1=False
num1=0
score1=0

#moto jaune
moto2X=LARGEUR//3
moto2Y=HAUTEUR//2
direction2='droite'
boost2=False
num2=0
score2=0

tempsPartie=0


def afficheTexte(x,y,txt,couleur):
        """
        affiche un texte aux coordonnées x,y
        """
        texteAfficher=font.render(str(txt),True,couleur)
        fenetre.blit(texteAfficher,(x,y))

def afficheScore(x,y,txt):
    pass
    """
    affiche un texte aux coordonnées x,y
    """
    pygame.draw.rect(fenetre, NOIR, [0, y, 512, 20],0)
    afficheTexte(x,y,txt,VERT)

def main_menu():
    click=False
    while True:

        menu=pygame.image.load('data/menu.png')
        mx,my=pygame.mouse.get_pos()

        button1=pygame.Rect(157,253,206,88)
        button2=pygame.Rect(157,357,206,88)

        if button1.collidepoint((mx,my)):
            if click:
                touches()

        if button2.collidepoint((mx,my)):
            if click:
                tableau()

        pygame.draw.rect(fenetre,(255,0,0),button1)
        pygame.draw.rect(fenetre,(255,0,0),button2)
        fenetre.blit(menu,(0,0))

        click=False
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                pygame.quit()
            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_ESCAPE:
                    pygame.quit()
            if event.type==pygame.MOUSEBUTTONDOWN:
                if event.button==1:
                    click=True

        pygame.display.update()

def tableau():
    click=False
    running=True
    while running:

        mx,my=pygame.mouse.get_pos()

        button3=pygame.Rect(1,1,71,73)

        if button3.collidepoint((mx,my)):
            if click:
                main_menu()

        pygame.draw.rect(fenetre,(255,0,0),button3)

        img=pygame.image.load('data/scores.png')
        fenetre.blit(img,(0,0))

        y=185
        for i in range(len(tab)):
            afficheTexte(140,y,i+1,ROUGE)
            y+=35

        y=185
        for nom,sc in tab.items():
            afficheTexte(190,y,sc,VERT)
            afficheTexte(330,y,nom,ROSE)
            y+=35


        click=False

        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                pygame.quit()
            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_ESCAPE:
                    pygame.quit()
            if event.type==pygame.MOUSEBUTTONDOWN:
                if event.button==1:
                    click=True

        #pygame.display.update()

def touches():
    running=True
    while running:

        mx, my=pygame.mouse.get_pos()

        button4=pygame.Rect(1,1,71,73)

        if button4.collidepoint((mx,my)):
            if click:
                main_menu()

        pygame.draw.rect(fenetre,(255,0,0),button4)

        touche=pygame.image.load('data/touches.png')
        fenetre.blit(touche,(0,0))

        keys = pygame.key.get_pressed()                                          #recupération des touches appuyées en continu
        if keys[pygame.K_SPACE]:
            tron()

        click=False

        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                pygame.quit()
            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_ESCAPE:
                    pygame.quit()
            if event.type==pygame.MOUSEBUTTONDOWN:
                if event.button==1:
                    click=True

        pygame.display.update()

def tron():

    def dessineDecor():
        global tempsPartie
        """
        dessine un decor

        """
        fond=pygame.image.load('data/fond.png')
        fenetre.blit(fond,(0,0))
        pygame.draw.rect(fenetre,ROUGE,[1,1,LARGEUR-1,HAUTEUR-1],5)

        for i in range(25):
            pass
            #pygame.draw.circle(fenetre, ROUGE, (randint(10,LARGEUR-9),randint(10,HAUTEUR-37)), 10)      #cercle plein aux coord x,y de rayon 10
            #pygame.draw.rect(fenetre, BLEU, [randint(0,LARGEUR+1),randint(0,HAUTEUR-27), 10, 10],0)     #rectangle plein aux coord x,y
        debut=True
        return debut

    def collisionMurMoto(x,y,num):
        global moto1X,moto1Y,moto2X,moto2Y
        """
        verifie si on touche un mur ou autre chose
        aucun obstacle correspond à une couleur noire
        """
        color=fenetre.get_at((x, y))[:3]
        if (color[0]==255 and color[1]==0) or color[2]==150:
            collision=True
        elif color[0]==249:
            collision=True
        elif color[1]==67:
            collision=True
        else:
            collision=False

        return collision

    def deplacementmoto1(boost1):
        global moto1X,moto1Y
        """
        deplace la moto si c'est possible
        """

        if boost1==True:
            n1=8
        else:
            n1=1

        touche1=False
        if direction1=='haut':
            x=moto1X
            y=moto1Y-n1
            touche1=collisionMurMoto(x,y,1)

        elif direction1=='bas':
            x=moto1X
            y=moto1Y+n1
            touche1=collisionMurMoto(x,y,1)

        elif direction1=='droite':
            y=moto1Y
            x=moto1X+n1
            touche1=collisionMurMoto(x,y,1)

        elif direction1=='gauche':
            y=moto1Y
            x=moto1X-n1
            touche1=collisionMurMoto(x,y,1)

        if touche1==False:                                                       #si pas d'obstacle alors on trace le point de la moto
            moto1X=x
            moto1Y=y
        fenetre.set_at((x, y), JAUNE)
        return touche1


    def deplacementmoto2(boost2):
        global moto2X,moto2Y

        if boost2==True:
            n2=8
        else:
            n2=1

        touche2=False
        if direction2=='haut':
            x=moto2X
            y=moto2Y-n2
            touche2=collisionMurMoto(x,y,2)

        elif direction2=='bas':
            x=moto2X
            y=moto2Y+n2
            touche2=collisionMurMoto(x,y,2)

        elif direction2=='droite':
            y=moto2Y
            x=moto2X+n2
            touche2=collisionMurMoto(x,y,2)

        elif direction2=='gauche':
            y=moto2Y
            x=moto2X-n2
            touche2=collisionMurMoto(x,y,2)

        if touche2==False:                                                       #si pas d'obstacle alors on trace le point de la moto
            moto2X=x
            moto2Y=y
        fenetre.set_at((x,y),ROSE)
        return touche2                                                           #retourne la variable booleenne touche pour savoir si la partie est terminée

    def tabScore(tempsPartie):
        nom=str(input("Nom du gagnant"))
        nom=nom.upper()
        tab[str(nom)]=tempsPartie
        fichier=open('data/scores.csv','a')
        fichier.write(str(nom))
        fichier.write(',')
        fichier.write(str(tempsPartie))
        fichier.write(',')

        tst.trier('data/scores.csv','data/tri.csv',1)

        tab2=tst.convert('data/tri.csv')
        print(tab2)

        f=open('data/scores.csv','w')
        f.write('Nom')
        f.write(',')
        f.write('Score\n')
        for nm,ss in tab2.items():
            f.write(str(nm))
            f.write(',')
            f.write(str(ss))
            f.write('\n')

        tableau()

    global tempsPartie

    #moto rose
    moto1X=(LARGEUR//3)*2
    moto1Y=HAUTEUR//2
    direction1='gauche'
    boost1=False
    num1=0
    score1=0

    #moto verte
    moto2X=LARGEUR//3
    moto2Y=HAUTEUR//2
    direction2='droite'
    boost2=False
    num2=0
    score2=0

    debut=dessineDecor()
    loop=True
    while loop==True:
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                loop=False                                                       #fermeture de la fenêtre (croix rouge)
            if event.type==pygame.KEYDOWN:                                       #une touche a été pressée...laquelle ?
                if event.key==pygame.K_ESCAPE or event.unicode=='q':             #touche q pour quitter
                    loop=False
            #fenetre.set_at((200, 200), color)

        keys = pygame.key.get_pressed()                                          #recupération des touches appuyées en continu


        if keys[pygame.K_UP]:                                                    #est-ce la touche UP
            direction1='haut'
        elif keys[pygame.K_DOWN]:                                                #est-ce la touche DOWN
            direction1='bas'
        elif keys[pygame.K_RIGHT]:                                               #est-ce la touche RIGHT
            direction1='droite'
        elif keys[pygame.K_LEFT]:                                                #est-ce la touche LEFT
            direction1='gauche'
        elif keys[pygame.K_RSHIFT]:                                            #est-ce la touche SHIFT DROIT
            if num1<3:
                boost1=True
                num1+=1


        if keys[pygame.K_w]:                                                     #est-ce la touche w
            direction2='haut'
        elif keys[pygame.K_s]:                                                   #est-ce la touche s
            direction2='bas'
        elif keys[pygame.K_d]:                                                   #est-ce la touche d
            direction2='droite'
        elif keys[pygame.K_a]:                                                   #est-ce la touche a
            direction2='gauche'
        elif keys[pygame.K_q]:                                                 #est-ce la touche SPACE
            if num2<3:
                boost2=True
                num2+=1


        #fenetre.fill((0,0,0))                                                   #efface la fenêtre, non utilisé ici
        afficheScore(250,520,tempsPartie)
        afficheTexte(400,520,score1,ROSE)
        afficheTexte(150,520,score2,JAUNE)

        if deplacementmoto1(boost1)==True: #or deplacementmoto2(boost2)==True:
            if moto1X==moto2X and moto1Y==moto2Y:
                fenetre.fill(Noir)
                col=pygame.image.load('data/col.png')
                fenetre.blit(col,(0,0))

            if deplacementmoto1(boost1)==True:
                score1+=1
                fenetre.fill(NOIR)
                j1m=pygame.image.load('data/j1m.png')
                fenetre.blit(j1m,(0,0))
            """
            elif deplacementmoto2(boost2)==True:
                score2+=1
                fenetre.fill(NOIR)
                j2m=pygame.image.load('data/j2m.png')
                fenetre.blit(j2m,(0,0))"""

            pygame.display.update()

            loop2=True
            while loop2==True:
                for event in pygame.event.get():
                    if event.type==pygame.QUIT:
                        loop=False                                                       #fermeture de la fenêtre (croix rouge)
                    if event.type==pygame.KEYDOWN:                                       #une touche a été pressée...laquelle ?
                        if event.key==pygame.K_ESCAPE or event.unicode=='q':             #touche q pour quitter
                            loop=False
                        elif event.key==pygame.K_SPACE:
                            moto1X=(LARGEUR//3)*2
                            moto1Y=HAUTEUR//2
                            direction1='gauche'
                            boost1=False

                            moto2X=LARGEUR//3
                            moto2Y=HAUTEUR//2
                            direction2='droite'
                            boost2=False

                            pygame.display.update()
                            dessineDecor()
                            debut=True
                            loop2=False

        frequence.tick(60)
        pygame.display.update()                                                  #mets à jour la fenêtre graphique
        if debut==True:
            time.sleep(1)
            debut=False

        if boost1==True:
            if pygame.time.get_ticks()-tempsPartie>2000:
                boost1=False

        if boost2==True:
            if pygame.time.get_ticks()-tempsPartie>2000:
                boost2=False

        tempsPartie+=1

        if score1==3 or score2==3:

            score=str(score1)+'/'+str(score2)
            afficheTexte(245,520,score,ROUGE)
            if score=='3/0' or score=='3/1' or score=='3/2':
                j1p=pygame.image.load('data/j1p.png')
                fenetre.blit(j1p,(0,0))
            elif score=='0/3' or score=='1/3' or score=='2/3':
                j2p=pygame.image.load('data/j2p.png')
                fenetre.blit(j2p,(0,0))

            pygame.display.update()

            loop2=True
            while loop2==True:
                for event in pygame.event.get():
                    if event.type==pygame.QUIT:
                        loop=False                                                       #fermeture de la fenêtre (croix rouge)
                    if event.type==pygame.KEYDOWN:                                       #une touche a été pressée...laquelle ?
                        if event.key==pygame.K_ESCAPE or event.unicode=='q':             #touche q pour quitter
                            loop=False
                        elif event.key==pygame.K_SPACE:
                            score1=0
                            score2=0
                            tempsPartie=0
                            tabScore(tempsPartie)
                            loop2=False

    pygame.quit()
    print('perdu')
    print('temps partie',tempsPartie)

main_menu()