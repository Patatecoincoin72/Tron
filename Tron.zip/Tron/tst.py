import csv

def lireFichier(nom):
    with open(nom,'r',newline='') as fichier:
        lect=csv.reader(fichier)
        lignes=list(lect)
    return lignes

def trier(entree,sortie,colonne):
    lignes=lireFichier(entree)
    triee=sorted(lignes[1:],key=lambda ligne: int(ligne[colonne]))
    triee.insert(0,lignes[0])
    print(triee)

    with open(sortie,'w',newline='') as fichierS:
        ecr=csv.writer(fichierS)
        ecr.writerows('')
        ecr.writerows(triee)

def convert(doc):
    fichier=open(doc,'r')
    lecture=csv.DictReader(fichier,delimiter=',')

    bat=[]
    for ligne in lecture:
        bat.append(dict(ligne))
    fichier.close()
    print(bat)

    tab={ps['Nom']:ps['Score'] for ps in bat}

    return tab
