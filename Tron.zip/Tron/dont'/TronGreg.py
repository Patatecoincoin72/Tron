"""
Programme du tron
Theard Gregory 1G9
"""
import pygame
from random import *

#constantes de la fenêtre d'affichage
LARGEUR=512       #hauteur de la fenêtre
HAUTEUR=512      #largeur de la fenêtre
ROUGE=(255,0,0)     # définition de 3 couleurs
VERT=(0,255,0)
BLEU=(0,0,255)
BLEU2=(0,0,254)
NOIR=(0,0,0)
TEST=(0,162,255)
MENU=(0,153,153)
MENU2=(0,0,1)
SCORE11=(0,254,0)
SCORE22=(254,0,0)
SCORE1=0
SCORE2=0
mouseX=0
mouseY=0


BLANC=(255,255,255)
ROUGE=(255,0,0)                                                                  #définition couleurs
VERT=(0,255,0)
BLEU=(0,0,150)
BLEUF=(0,0,139)
ROSE=(255,67,117)
JAUNE=(249,225,69)

#Utilisation de la bibliothèque pygame
pygame.init()
fenetre = pygame.display.set_mode((LARGEUR, HAUTEUR))
pygame.display.set_caption("Tron")             #titre de la fenêtre
font = pygame.font.Font('freesansbold.ttf', 20)     #choix de la police de caractères
frequence = pygame.time.Clock()                     #mode animation dans pygame
motoX=LARGEUR//2
motoY=HAUTEUR//2
motoX2=400
motoY2=400
direction = 'haut'
direction2 = 'haut'
tempsPartie=0
tempsseconde=0
def dessineDecor():
    """
    dessine un decor
    """
    pygame.draw.rect(fenetre, ROUGE, [1, 1, LARGEUR-1, HAUTEUR-1],1)
    for i in range(0,10):
        pygame.draw.circle(fenetre, ROUGE, (randint(1,511),randint(1,511)), 10)      #cercle plein aux coord x,y de rayon 10
        pygame.draw.rect(fenetre, BLEU, [randint(1,511), randint(1,511), 10, 10],0)  #rectangle plein aux coord x,y
    pygame.draw.rect(fenetre, NOIR, [motoX-5,motoY-80, 10,80],0)  #Protection de départ
    pygame.draw.rect(fenetre, NOIR, [motoX2-5,motoY2-80, 10,80],0)  #Protection de départ



def affichetxt(x,y,txt):
    """
    affiche un texte aux coordonnées x,y
    """
    texteAfficher = font.render(str(txt), True, MENU)
    fenetre.blit(texteAfficher,(x,y))

def affichetxt2(x,y,txt):
    """
    affiche un texte aux coordonnées x,y
    """
    texteAfficher = font.render(str(txt), True, TEST)
    fenetre.blit(texteAfficher,(x,y))


def afficheScore(x,y,txt):
    """
    affiche un texte aux coordonnées x,y
    """
    texteAfficher = font.render(str(txt), True, SCORE11)
    pygame.draw.rect(fenetre, NOIR, [x, y, 15, 20],0)
    fenetre.blit(texteAfficher,(x,y))

def afficheScore3(x,y,txt):
    """
    affiche un texte aux coordonnées x,y
    """
    texteAfficher = font.render(str(txt), True, BLEU2)
    pygame.draw.rect(fenetre, NOIR, [x, y, 30, 20],0)
    fenetre.blit(texteAfficher,(x,y))


def afficheScore2(x,y,txt):
    """
    affiche un texte aux coordonnées x,y
    """
    texteAfficher = font.render(str(txt), True, SCORE22)
    pygame.draw.rect(fenetre, NOIR, [x, y, 15, 20],0)
    fenetre.blit(texteAfficher,(x,y))

def collisionMur(x,y):
    """
    verifie si on touche un mur ou autre chose
    aucun obstacle correspond à une couleur noire
    """
    color=fenetre.get_at((x, y))[:3]
    if color[0]==255:
        collision=True
    elif color[1]==255:
        collision=True
    elif color[2]==255:
        collision=True
    else:
        collision=False
    return collision

def deplacementmoto():
    """
    deplace la moto si c'est possible
    """
    global motoX,motoY
    touche=False
    if direction=='haut':
        x=motoX
        y=motoY-1
        touche=collisionMur(x,y)
    elif direction=='bas':
        x=motoX
        y=motoY+1
        touche=collisionMur(x,y)
    elif direction=='droite':
        x=motoX+1
        y=motoY
        touche=collisionMur(x,y)
    elif direction=='gauche':
        x=motoX-1
        y=motoY
        touche=collisionMur(x,y)
    if touche==False:       #si pas d'obstacle alors on trace le point de la moto
        motoX=x
        motoY=y
    fenetre.set_at((x, y), VERT)
    return touche           #retourne la variable booleenne touche pour savoir si la partie est terminée

def deplacementmoto2():
    """
    deplace la moto si c'est possible
    """
    global motoX2,motoY2
    touche2=False
    if direction2=='haut':
        X=motoX2
        Y=motoY2-1
        touche2=collisionMur(X,Y)
    elif direction2=='bas':
        X=motoX2
        Y=motoY2+1
        touche2=collisionMur(X,Y)
    elif direction2=='droite':
        X=motoX2+1
        Y=motoY2
        touche2=collisionMur(X,Y)
    elif direction2=='gauche':
        X=motoX2-1
        Y=motoY2
        touche2=collisionMur(X,Y)
    if touche2==False:       #si pas d'obstacle alors on trace le point de la moto
        motoX2=X
        motoY2=Y
    fenetre.set_at((X, Y), ROUGE)
    return touche2           #retourne la variable booleenne touche pour savoir si la partie est terminée



loop=False
while loop==False:
    fenetre.fill((21,51,0))
    pygame.draw.rect(fenetre, MENU2, [ 200, 380, 100, 30],0)
    pygame.draw.rect(fenetre, MENU2, [ 225, 380, 100, 30],0)
    pygame.draw.circle(fenetre, ROUGE, (200,300), 30)
    pygame.draw.circle(fenetre, ROUGE, (300,300), 30)
    pygame.draw.rect(fenetre, ROUGE, [ 190, 250, 20, 70],0)
    pygame.draw.rect(fenetre, ROUGE, [ 290, 250, 20, 70],0)
    pygame.draw.rect(fenetre, ROUGE, [ 200, 240, 100, 30],0)
    pygame.draw.rect(fenetre, NOIR, [ 170, 240, 30, 10],0)
    pygame.draw.rect(fenetre, ROUGE, [ 290, 190, 20, 70],0)
    pygame.draw.rect(fenetre, NOIR, [ 245, 190, 70, 20],0)
    pygame.draw.circle(fenetre, NOIR, (300,300), 5)
    pygame.draw.circle(fenetre, NOIR, (200,300), 5)
    affichetxt2(225,350,"TRON")
    affichetxt(210,385,"< START >")
    affichetxt2(20,80,"THEARD Gregory 1G9")
    pygame.display.update() #mets à jour la fenêtre graphique
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouseX, mouseY = pygame.mouse.get_pos()
            color=fenetre.get_at((mouseX,mouseY))[:3]
            if color==(MENU[0],MENU[1],MENU[2]) or color==(MENU2[0],MENU2[1],MENU2[2]):
                fenetre.fill((0,0,0))
                loop=True




if loop==True:
    dessineDecor()
while loop==True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            loop = False            #fermeture de la fenêtre (croix rouge)
        if event.type == pygame.KEYDOWN:  #une touche a été pressée...laquelle ?
            if event.key == pygame.K_ESCAPE: #touche q pour quitter
                loop = False
            #fenetre.set_at((200, 200), color)

    keys = pygame.key.get_pressed()         #recupération des touches appuyées en continu
    if keys[pygame.K_UP]:    #est-ce la touche UP
        if direction!="bas":
            direction = 'haut'
    elif keys[pygame.K_DOWN]:  #est-ce la touche DOWN
        if direction!="haut":
            direction = 'bas'
    elif keys[pygame.K_RIGHT]:  #est-ce la touche RIGHT
        if direction!="gauche":
            direction = 'droite'
    elif keys[pygame.K_LEFT]:  #est-ce la touche LEFT
        if direction!="droite":
            direction = 'gauche'
    elif keys[pygame.K_w]:    #est-ce la touche UP
        if direction2!="bas":
            direction2 = 'haut'
    elif keys[pygame.K_s]:  #est-ce la touche DOWN
        if direction2!="haut":
            direction2 = 'bas'
    elif keys[pygame.K_d]:  #est-ce la touche RIGHT
        if direction2!="gauche":
            direction2 = 'droite'
    elif keys[pygame.K_a]:  #est-ce la touche LEFT
        if direction2!="droite":
            direction2 = 'gauche'


    #fenetre.fill((0,0,0))   #efface la fenêtre, non utilisé ici
    afficheScore3(180,490,tempsseconde)
    afficheScore(280,490,SCORE1)
    afficheScore2(300,490,SCORE2)
    if deplacementmoto()==True:    #Score associé à la mort des joueurs
        SCORE2+=1
        fenetre.fill((0,0,0))
        motoX=256       #On remet les joueurs à la place initiale
        motoY=256
        motoX2=400
        motoY2=400
        dessineDecor()
        direction="haut"
        direction2="haut"
    elif deplacementmoto2()==True:
        SCORE1+=1
        fenetre.fill((0,0,0))
        motoX=256
        motoY=256
        motoX2=400
        motoY2=400
        dessineDecor()
        direction="haut"
        direction2="haut"
    frequence.tick(60)
    pygame.display.update() #mets à jour la fenêtre graphique
    tempsPartie+=1
    if tempsPartie%60==0:
        tempsseconde+=1
        tempsPartie=0
    if SCORE1==3:
        print("Le premier joueur a gagné")
        loop=False
    elif SCORE2==3:
        print("Le deuxième joueur a gagné")
        loop=False
pygame.quit()
print('temps partie',tempsseconde,'seconde(s)')
print("Score du premier joueur:",SCORE1,"Score du deuxième joueur:",SCORE2)


